using Pulumi;

using K8s = Pulumi.Kubernetes;

class MyStack : Stack
{
    public MyStack()
    {
    }
}
